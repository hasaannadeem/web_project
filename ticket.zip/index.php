﻿<!DOCTYPE html>
<head>

	<title>Online Ticket Reservation</title>	
<link rel="stylesheet" type="text/css" href="library/font-awesome-4.3.0/css/font-awesome.min.css">
<link rel="shortcut icon" type="image/x-icon" href="images/icon.png">
<link rel="stylesheet" type="text/css" href="library/bootstrap/css/bootstrap-theme.min.css">
<link rel="stylesheet" type="text/css" href="library/bootstrap/css/bootstrap.css">
<link rel="stylesheet" type="text/css" href="css/style.css">
<link rel="stylesheet" type="text/css" href="css/responsive.css">
<link rel="stylesheet" type="text/css" href="css/color.css">
        
</head>
<body>
	
    <div class="preloader">
<div class="loader theme_background_color">
<span></span>
</div>
</div>
<div class="wrapper">
<nav  class=" nim-menu navbar navbar-default navbar-fixed-top">
<div class="container">
<div class="navbar-header">
<button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">
            
<span class="sr-only">Toggle navigation</span>        
<span class="icon-bar"></span>
<span class="icon-bar"></span> 
<span class="icon-bar"></span>      
</button>        
<a class="navbar-brand" href="index.html">Online Tickets</a>        
</div>
       
<div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
          
<ul class="nav navbar-nav navbar-right">        
<li><a href="#home" class="page-scroll"><h3>Home</h3></a></li>
<li><a href="" class="page-scroll"><h3>Services</h3></a></li>
<li><a href="admin/" class="page-scroll"><h3>Login</h3></a></li>
</ul>
</div>   
</nav>


<section class="main-heading" id="home">
<div class="overlay">  
<div class="container">         
<div class="row">             
<div class="main-heading-content col-md-12 col-sm-12 text-center">   
<h1 class="main-heading-title">Online Ticket</h1>
<h1 class="main-heading-title">Reservation System</h1>
       
<p class="main-heading-text">Presented by,<br>Hasaan Nadeem<br>Muhammad Muneeb<br>Muhammad Danish</p>
        
<div class="btn-bar">
<a href="reserved.php" class="btn btn-custom theme_background_color">Reserve Now</a>
</div>      
</div>         
</div>     
</div> 
</div>  
</section>
 


<section class="aboutus white-background black" id="one">
<div class="container">
<div class="row">
<div class="col-md-12 text-center black">
<h3 class="title">SERVICES</h3>
            
<p class="a-slog">Providing Quality Service At Extremely Low Price</p>           
</div>    
</div>
         
<div class="gap">   
</div>
<div class="row about-box">
          
<div class="col-sm-4 text-center">
            
<div class="margin-bottom">
              
<i class="fa fa-bus"></i>
              
<h4>BUS</h4>
             
            
</div> 
          
</div> 
          
<div class="col-sm-4 about-line text-center">
            
<div class="margin-bottom">
              
<i class="fa fa-train"></i>
              
<h4>TRAIN</h4>
            
</div> <!-- / margin -->
          
</div><!-- /col -->
          
<div class="col-sm-4 text-center">
            
<div class="margin-bottom">
              
<i class="fa fa-plane"></i>
              
<h4>AIRPALNE</h4>
              
            
</div> <!-- / margin -->
          
</div><!-- /col -->
        
</div> <!-- /row -->     
</div>
 </section>
 
<section class="sub-form text-center" id="eight">
  
<div class="container">
    <div class="col-md-12">
        
<h3 class="title">Subscribe to our <span class="themecolor"> Newsletter</span></h3>         
</div> 
<div class="row">
<div class="col-md-3 col-sm-3"></div>
<div class="col-md-6 center-block col-sm-6 ">
<form id="mc-form">
<div class="input-group">
<input type="email" class="form-control" placeholder="Email Address" required id="mc-email">
<span class="input-group-btn">
<button type="submit" class="btn btn-default">SUBSCRIBE <i class="fa fa-envelope"></i> </button>
</span> </div>
<label for="mc-email" id="mc-notification"></label>
 </form>
</div>
 </div>
</div>
</section>


<footer class="site-footer section-spacing text-center " id="eight">
<div class="container">
<div class="row">
<div class="col-md-4">
<p class="footer-links"><a href="#">Terms of Use</a> <a href="#">Privacy Policy</a></p>
</div>
<div class="col-md-4"> <small>&copy; 2020, WAD-F17</small></div>
<div class="col-md-4"> 
<ul class="social">
<li><a href="https://twitter.com/" target="_blank"><i class="fa fa-twitter "></i></a></li>
<li><a href="https://www.facebook.com/" target="_blank"><i class="fa fa-facebook"></i></a></li>
<li><a href="https://www.youtube.com/" target="_blank"><i class="fa fa-youtube-play"></i></a></li>   
</ul>
</div>
</div>
</div>
</footer>
</div>

	
<script src="library/jquery-1.11.3.min.js"></script>
        
<script src="library/bootstrap/js/bootstrap.js"></script>
	
<script type="text/javascript" src="js/jquery.easing.1.3.js"></script>	
	    
<script src="library/vegas/vegas.min.js"></script>

<script src="js/typed.js"></script>
         
<script src="js/fappear.js"></script>
       
<script src="js/jquery.countTo.js"></script>

<script src="js/owl.carousel.js"></script>
         
<script src="js/jquery.magnific-popup.min.js" type="text/javascript"></script>
        
<script type="text/javascript" src="js/SmoothScroll.js"></script>
        
        
<script src="js/common.js"></script>
  
</body>


</html>